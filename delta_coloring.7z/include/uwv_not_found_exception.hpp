#ifndef DELTACOLORING_UWV_NOT_FOUND_EXCEPTION
#define DELTACOLORING_UWV_NOT_FOUND_EXCEPTION

#include <exception>

namespace dColoring {
	class uwv_not_found_exception: public std::exception {

	};
}

#endif //DELTACOLORING_UWV_NOT_FOUND_EXCEPTION