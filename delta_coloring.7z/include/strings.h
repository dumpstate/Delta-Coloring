#ifndef DELTACOLORING_STRINGS
#define DELTACOLORING_STRINGS

#include <string>

using std::string;

namespace dColoring{
	const string USAGE = "USAGE:\n\t deltacoloring in [out]\n";
}

#endif //DELTACOLORING_STRINGS
